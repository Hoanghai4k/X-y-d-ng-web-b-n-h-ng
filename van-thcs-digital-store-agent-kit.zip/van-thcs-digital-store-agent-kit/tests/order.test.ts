import { describe, expect, it } from "vitest";
import {
  assertOrderTransition,
  assertValidVndAmount,
  canTransitionOrder,
  normalizeBuyerEmail,
} from "../src/domain/order";

describe("order state machine", () => {
  it("allows payment then delivery", () => {
    expect(canTransitionOrder("PENDING", "PAID")).toBe(true);
    expect(canTransitionOrder("PAID", "DELIVERY_PENDING")).toBe(true);
    expect(canTransitionOrder("DELIVERY_PENDING", "DELIVERED")).toBe(true);
  });

  it("rejects client-like jump from pending to delivered", () => {
    expect(() => assertOrderTransition("PENDING", "DELIVERED")).toThrow(
      "Invalid order transition",
    );
  });

  it("does not reopen terminal orders", () => {
    expect(canTransitionOrder("CANCELLED", "PAID")).toBe(false);
    expect(canTransitionOrder("REFUNDED", "DELIVERED")).toBe(false);
  });
});

describe("buyer and money rules", () => {
  it("normalizes email", () => {
    expect(normalizeBuyerEmail("  Teacher@Example.COM ")).toBe(
      "teacher@example.com",
    );
  });

  it("accepts positive integer VND", () => {
    expect(() => assertValidVndAmount(79_000)).not.toThrow();
  });

  it.each([0, -1, 79_000.5, Number.NaN, Number.POSITIVE_INFINITY])(
    "rejects invalid VND amount %s",
    (amount) => {
      expect(() => assertValidVndAmount(amount)).toThrow();
    },
  );
});
