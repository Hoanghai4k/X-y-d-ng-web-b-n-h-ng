export const ORDER_STATUSES = [
  "PENDING",
  "PAID",
  "DELIVERY_PENDING",
  "DELIVERED",
  "EXPIRED",
  "CANCELLED",
  "REFUND_REVIEW",
  "REFUNDED",
] as const;

export type OrderStatus = (typeof ORDER_STATUSES)[number];

const ALLOWED_TRANSITIONS: Readonly<Record<OrderStatus, readonly OrderStatus[]>> = {
  PENDING: ["PAID", "EXPIRED", "CANCELLED"],
  PAID: ["DELIVERY_PENDING", "REFUND_REVIEW"],
  DELIVERY_PENDING: ["DELIVERED", "REFUND_REVIEW"],
  DELIVERED: ["REFUND_REVIEW"],
  EXPIRED: [],
  CANCELLED: [],
  REFUND_REVIEW: ["REFUNDED"],
  REFUNDED: [],
};

export function canTransitionOrder(
  current: OrderStatus,
  next: OrderStatus,
): boolean {
  return ALLOWED_TRANSITIONS[current].includes(next);
}

export function assertOrderTransition(
  current: OrderStatus,
  next: OrderStatus,
): void {
  if (!canTransitionOrder(current, next)) {
    throw new Error(`Invalid order transition: ${current} -> ${next}`);
  }
}

export function normalizeBuyerEmail(email: string): string {
  return email.trim().toLowerCase();
}

export function assertValidVndAmount(amountVnd: number): void {
  if (!Number.isSafeInteger(amountVnd) || amountVnd <= 0) {
    throw new Error("amountVnd must be a positive safe integer");
  }
}
