# 01 — Product Requirements Document

## Vấn đề hiện tại

Người bán đang đăng tài liệu trong các nhóm Facebook. Khách phải nhắn tin, nhận số tài khoản, chuyển khoản, gửi ảnh giao dịch và chờ người bán gửi file thủ công.

## Mục tiêu

Tự động hóa từ lúc khách bấm link sản phẩm tới lúc nhận tài liệu, nhưng không xây hệ thống tài khoản khách hàng phức tạp.

## Người dùng

### Khách mua

- Giáo viên, phụ huynh hoặc học sinh.
- Truy cập chủ yếu bằng điện thoại từ Facebook.
- Muốn xem nhanh, thanh toán QR nhanh và nhận tài liệu ngay.

### Người bán/Admin

- Đăng sản phẩm, giá, ảnh/bản mẫu và file nguồn.
- Xem đơn hàng và trạng thái giao tài liệu.
- Gửi lại email khi khách báo chưa nhận được.
- Không muốn vận hành hệ thống phức tạp.

## Chức năng MVP

### Public

- Danh sách sản phẩm.
- Trang chi tiết theo slug.
- Ảnh/bản xem trước không chứa toàn bộ tài liệu.
- Form mua ngay: email, xác nhận email, số điện thoại.
- Chuyển hướng tới checkout payOS.
- Trang kết quả chỉ hiển thị trạng thái tham khảo và hướng dẫn kiểm tra email.
- Trang tải tài liệu bằng token ký số.

### Admin

- CRUD sản phẩm.
- Upload/chọn file tài liệu private.
- Xem và lọc đơn hàng.
- Xem lịch sử webhook và giao email.
- Gửi lại email giao tài liệu.
- Vô hiệu hóa download grant khi cần.

## Ngoài phạm vi MVP

- Đăng ký/đăng nhập khách hàng.
- Giỏ hàng nhiều sản phẩm.
- Mã giảm giá.
- Affiliate.
- Subscription.
- Hệ thống học LMS.
- Chatbot tư vấn.
- Agent tự tạo học liệu.

## Chỉ số thành công ban đầu

- Tỷ lệ đơn `PAID` được cấp quyền tải tự động ≥ 99%.
- Không giao file trước khi webhook hợp lệ.
- Webhook gửi lặp không tạo delivery trùng.
- Khách hoàn tất từ form tới QR trong tối đa 2 màn hình.
- Admin tìm và gửi lại đơn trong dưới 1 phút.
