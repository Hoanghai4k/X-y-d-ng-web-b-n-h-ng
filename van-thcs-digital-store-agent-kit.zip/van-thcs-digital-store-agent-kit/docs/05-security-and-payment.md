# 05 — Security and Payment

## Payment

- Khởi tạo payOS SDK chỉ ở server.
- Secret chỉ đọc từ environment variables.
- Webhook bắt buộc gọi SDK verify.
- Đối chiếu orderCode, amount và order hiện tại.
- Xử lý trong transaction.
- Thiết kế idempotent trước khi thêm side effect.

## Download

- Không dùng UUID order làm download token.
- Sinh token entropy cao, chỉ lưu hash.
- Token có expiry và download limit.
- Signed storage URL chỉ tồn tại ngắn hạn.
- Chống race khi tăng download count bằng atomic update/transaction.

## PII

- Chỉ thu email và số điện thoại cần thiết.
- Không log toàn bộ payload hoặc token.
- Admin audit khi sửa email hoặc gửi lại tài liệu.
- Có chính sách retention sau khi vận hành thực tế.

## Admin

- Admin auth tách khỏi customer flow.
- Bảo vệ CSRF nếu dùng cookie session.
- Rate limit route nhạy cảm.
- Không để admin upload file thực thi.
- Validate MIME/type và extension; file bán chủ yếu PDF/DOCX/ZIP theo whitelist.

## Agent safety

- Không chạy script lạ từ repo tham khảo.
- Không tự bật quyền terminal/network toàn phần.
- Không commit `.env`.
- Trước migration phá dữ liệu phải yêu cầu review.
