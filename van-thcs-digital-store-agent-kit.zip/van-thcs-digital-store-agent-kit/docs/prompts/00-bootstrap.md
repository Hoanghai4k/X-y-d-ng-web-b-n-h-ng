# Prompt 00 — Bootstrap

Dán prompt này vào Antigravity:

```text
Hãy đọc AGENTS.md, GEMINI.md, toàn bộ docs/01 đến docs/06 và TASKS.md.

Chưa sửa code. Trước tiên:
1. Tóm tắt mục tiêu MVP và các nội dung ngoài phạm vi.
2. Khảo sát starter code và lệnh kiểm tra hiện có.
3. Đề xuất kế hoạch thực hiện Phase 0 theo từng task, nêu rõ file dự kiến thay đổi.
4. Chỉ ra các quyết định cần ghi ADR.
5. Chỉ ra rủi ro lớn nhất ở webhook, idempotency và giao file.

Kết thúc sau implementation plan để tôi duyệt.
```
