# Prompt 01 — Thực hiện một task

```text
Thực hiện task [MÃ TASK] trong TASKS.md.

Quy trình bắt buộc:
1. Đọc AGENTS.md và tài liệu liên quan.
2. Explore code hiện tại trước khi sửa.
3. Viết plan ngắn gồm file thay đổi, test và rủi ro.
4. Triển khai đúng phạm vi task, không thêm chức năng ngoài MVP.
5. Chạy npm test và npm run typecheck.
6. Báo cáo acceptance criteria, file thay đổi, kết quả test và phần còn lại.

Không tự chuyển sang task kế tiếp.
```
