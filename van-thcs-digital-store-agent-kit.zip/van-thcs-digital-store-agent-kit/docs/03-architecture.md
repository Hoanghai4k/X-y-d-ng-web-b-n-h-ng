# 03 — Architecture

## Kiến trúc MVP

```text
Facebook
   ↓
Next.js Web App
   ├── Storefront pages
   ├── Route handlers / Server actions
   ├── Admin pages
   └── Background delivery adapter
          ↓
PostgreSQL
          ↓
Private Object Storage

External:
- payOS: create payment link + webhook
- Email provider: transactional delivery email
```

## Module boundaries

- `catalog`: sản phẩm, giá, slug, preview.
- `checkout`: validate buyer input, create pending order, create payment link.
- `payments`: verify webhook, reconcile payment, enforce idempotency.
- `delivery`: issue/revoke grant, send email, track attempts.
- `downloads`: validate token and grant access.
- `admin`: product/order operations and audit.

## Quyết định đơn giản hóa

- Một deployable Next.js app.
- Một PostgreSQL database.
- Không message broker trong bước đầu; dùng transactional outbox + scheduled worker hoặc managed queue nhỏ nếu cần.
- Không microservice.

## Ranh giới tin cậy

- Browser/client là không tin cậy.
- `returnUrl` là không tin cậy cho payment state.
- payOS webhook chỉ tin cậy sau verify signature.
- Object storage phải private.
- Admin routes cần authentication và authorization.
