# 02 — User Flows

## Flow A — Mua thành công

1. Khách vào `/san-pham/:slug` từ Facebook.
2. Bấm `Mua ngay`.
3. Nhập email, xác nhận email, số điện thoại.
4. Backend kiểm tra sản phẩm đang bán và lấy giá từ database.
5. Backend tạo orderCode duy nhất và đơn `PENDING`.
6. Backend gọi payOS tạo payment link.
7. Khách quét QR và thanh toán.
8. payOS gọi webhook.
9. Backend xác minh chữ ký và đối chiếu dữ liệu.
10. Trong transaction: chuyển `PENDING → PAID`, tạo delivery job/outbox nếu chưa tồn tại.
11. Worker hoặc job gửi email và tạo grant.
12. Đơn chuyển `DELIVERED` khi email provider chấp nhận gửi.

## Flow B — Khách quay lại từ returnUrl trước webhook

- Không chuyển đơn sang `PAID`.
- Hiển thị “Đang xác nhận thanh toán”.
- Client có thể polling endpoint trạng thái đọc-only trong thời gian giới hạn.

## Flow C — Webhook gửi lặp

- Xác minh webhook.
- Tìm event/order đã xử lý.
- Trả 2xx nhưng không tạo grant và email thứ hai.

## Flow D — Số tiền không khớp

- Không chuyển `PAID`.
- Lưu webhook audit đã che dữ liệu nhạy cảm.
- Gắn cờ `PAYMENT_REVIEW_REQUIRED` trong audit/incident, không nhất thiết thêm order status.
- Admin xử lý thủ công.

## Flow E — Email gửi lỗi

- Đơn có thể ở `DELIVERY_PENDING`.
- Retry theo giới hạn.
- Admin có thể gửi lại.
- Retry không được tạo nhiều grant hoạt động nếu chính sách chỉ cho một grant.

## Flow F — Khách tải tài liệu

1. Mở link có opaque token.
2. Backend hash token để tra grant.
3. Kiểm tra grant còn hiệu lực, chưa revoke, còn lượt tải và order đã thanh toán.
4. Tạo signed URL ngắn hạn hoặc stream file.
5. Tăng lượt tải theo cơ chế tránh race condition.
