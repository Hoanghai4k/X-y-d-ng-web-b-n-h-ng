# 04 — Data Model

## Product

- `id`: UUID
- `slug`: unique
- `title`
- `description`
- `priceVnd`: integer
- `status`: DRAFT | ACTIVE | ARCHIVED
- `previewAssets`: metadata
- `storageObjectKey`: secret/private reference
- timestamps

## Order

- `id`: UUID
- `orderCode`: unique integer/string compatible with payOS
- `productId`
- `buyerEmail`
- `buyerEmailNormalized`
- `buyerPhone`
- `amountVnd`: integer snapshot
- `status`
- `paymentLinkId`: nullable, unique when present
- `paidAt`: nullable
- timestamps

## PaymentWebhookEvent

- `id`
- `provider`: PAYOS
- `providerEventKey` or deterministic dedup key
- `orderCode`
- `signatureVerified`
- `payloadRedacted`
- `processedAt`
- `processingResult`
- unique dedup constraint

## DeliveryGrant

- `id`
- `orderId`
- `tokenHash`: unique
- `expiresAt`
- `maxDownloads`
- `downloadCount`
- `revokedAt`: nullable
- timestamps

## DeliveryAttempt

- `id`
- `orderId`
- `grantId`
- `channel`: EMAIL
- `providerMessageId`: nullable
- `status`: PENDING | SENT | FAILED
- `attemptNumber`
- `errorCode`: nullable
- timestamps

## AuditLog

- actor type/id
- action
- target type/id
- metadata redacted
- timestamp

## Constraints

- Giá và số tiền dùng integer VND.
- Không lấy giá từ request client.
- `Order.amountVnd` là snapshot tại thời điểm checkout.
- Một order không được có nhiều active delivery grants nếu chưa có quyết định nghiệp vụ khác.
