# 06 — Definition of Done

## Chung

- Acceptance criteria pass.
- Unit/integration test cho happy path và edge cases quan trọng.
- `npm test` pass.
- `npm run typecheck` pass.
- Không secret trong git diff.
- Error message không lộ internal detail.

## Checkout

- Giá lấy từ database.
- Email được normalize và confirm match.
- OrderCode unique.
- Không tạo payment link cho product inactive.

## Webhook

- Signature được verify bằng SDK/provider adapter.
- Amount/orderCode được đối chiếu.
- Idempotency được test bằng gọi cùng payload hai lần.
- Side effect delivery chỉ enqueue đúng một lần.
- Endpoint trả mã phù hợp để provider retry khi lỗi tạm thời.

## Delivery

- Không gửi public file URL.
- Token chỉ lưu dạng hash.
- Có expiry/revoke/download limit.
- Email retry không phát hành grant ngoài ý muốn.

## UI mobile

- Form dùng được trên màn hình nhỏ.
- CTA rõ ràng.
- Không bắt tạo tài khoản.
- Trạng thái pending không tuyên bố thanh toán thành công.
