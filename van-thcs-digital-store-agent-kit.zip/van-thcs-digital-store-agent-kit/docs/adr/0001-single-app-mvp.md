# ADR 0001 — Một ứng dụng Next.js cho MVP

## Status

Accepted.

## Context

Sản phẩm cần storefront, checkout, webhook, admin và delivery đơn giản. Chủ dự án không muốn web quá phức tạp.

## Decision

Dùng một Next.js full-stack application và một PostgreSQL database. Không tách microservice/FastAPI trong MVP.

## Consequences

- Triển khai và vận hành đơn giản.
- Domain boundaries vẫn phải rõ trong code.
- Có thể tách service về sau khi tải hoặc đội ngũ tăng.
