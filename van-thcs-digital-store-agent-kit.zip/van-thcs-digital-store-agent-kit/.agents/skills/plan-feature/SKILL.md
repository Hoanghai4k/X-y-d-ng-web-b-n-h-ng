---
name: plan-feature
description: Lập kế hoạch triển khai một feature của website bán tài liệu số trước khi sửa code; dùng khi task chạm nhiều file, database, thanh toán hoặc delivery.
---

# Plan Feature

1. Đọc `AGENTS.md` và tài liệu liên quan.
2. Explore code path hiện tại.
3. Xác định acceptance criteria từ `TASKS.md`/docs.
4. Liệt kê file tạo/sửa, migration, API contract và test.
5. Đánh dấu thay đổi có side effect hoặc security impact.
6. Không viết code trong bước lập kế hoạch.
