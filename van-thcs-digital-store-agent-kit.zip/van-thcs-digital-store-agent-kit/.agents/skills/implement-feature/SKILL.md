---
name: implement-feature
description: Triển khai một task đã có kế hoạch trong repo, giữ phạm vi MVP và bắt buộc chạy test/typecheck.
---

# Implement Feature

- Chỉ triển khai plan đã được thống nhất.
- Route handler phải mỏng; domain/service chịu nghiệp vụ.
- External SDK phải qua adapter.
- Bổ sung test trước hoặc cùng lúc với code.
- Chạy `npm test` và `npm run typecheck`.
- Không tự chuyển task kế tiếp.
