---
name: verify-digital-delivery
description: Kiểm tra cơ chế giao tài liệu số qua email và download token về bảo mật, expiry, revoke, giới hạn lượt tải và retry.
---

# Verify Digital Delivery

- File storage không public.
- Token có entropy cao và chỉ lưu hash.
- Grant gắn với order đã PAID.
- Kiểm tra expiry, revoke, maxDownloads bằng atomic operation.
- Signed URL ngắn hạn hoặc stream qua backend.
- Retry email không tạo grant trùng.
- Không log raw token.
