---
name: review-payment-webhook
description: Review code payOS webhook về xác minh chữ ký, đối chiếu số tiền, transaction, idempotency và side effects.
---

# Review Payment Webhook

Kiểm tra bắt buộc:

1. SDK verify được gọi trước khi tin payload.
2. `orderCode` và `amount` được so với database.
3. `returnUrl` không thay đổi payment status.
4. Dedup constraint tồn tại ở database.
5. Cùng webhook gọi hai lần chỉ tạo một delivery job.
6. Transaction bao phủ order update và outbox/delivery enqueue.
7. Log đã redacted.
8. Có test invalid signature, amount mismatch, unknown order và replay.
